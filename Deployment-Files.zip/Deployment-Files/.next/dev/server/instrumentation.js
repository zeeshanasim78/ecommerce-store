var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_1tjf0bv._.js")
R.c("server/chunks/src_instrumentation_ts_07j_8w1._.js")
R.m("[project]/src/instrumentation.ts [instrumentation] (ecmascript)")
module.exports=R.m("[project]/src/instrumentation.ts [instrumentation] (ecmascript)").exports
