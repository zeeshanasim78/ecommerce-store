:HL["/_next/static/chunks/18_wqr-nqjetc.css","style"]
:HL["/_next/static/media/cb065f3ef140709c-s.p.1eqdc75fykitr.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(storefront)","param":null,"prefetchHints":4128,"slots":{"children":{"name":"cart","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"7bUxZrO0opDQ137dLDwPk"}
